({
    handleActualizarLista : function(component, event, helper) {

        helper.actualizar(component);

    }
})