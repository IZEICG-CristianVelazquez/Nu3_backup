({
    
    actualizar : function(component, event, helper) {
        helper.actualizarClientes(component,event);
    }
})